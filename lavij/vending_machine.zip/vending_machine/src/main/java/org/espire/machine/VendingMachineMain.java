package org.espire.machine;

import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.espire.machine.bucket.Bucket;
import org.espire.machine.bucket.Coin;
import org.espire.machine.product.Inventory;
import org.espire.machine.product.InventoryMapping;
import org.espire.machine.product.Product;

public class VendingMachineMain {
  
  Bucket bucket = new Bucket();
  InventoryMapping inventory = new InventoryMapping();
  
  Product product = new Product(null, null, null, null, null);
  inventory.
 
}

