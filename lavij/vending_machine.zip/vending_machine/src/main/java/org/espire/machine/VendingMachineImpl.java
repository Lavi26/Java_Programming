package org.espire.machine;


import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import org.espire.machine.bucket.Bucket;
import org.espire.machine.bucket.Coin;
import org.espire.machine.product.Inventory;
import org.espire.machine.product.InventoryMapping;
import org.espire.machine.product.Product;


public class VendingMachineImpl implements VendingMachine {

  private InventoryMapping inventory = new InventoryMapping();
  

  private void initialize() {
    inventory.add(productId, product);(20, new Product(1, "COKE",  40.0));
    inventory.putInventory(30, new Product(2, "PEPSI",  30));
    inventory.putInventory(20, new Product(3, "CHIPS", 10));
    inventory.putInventory(40, new Product(4, "CHOCO", 20));
  }



  @Override
  public Bucket getItemsAndChange(int coinValue) {
    // TODO Auto-generated method stub
    return null;
  }



  @Override
  public long selectProductAndGetPrice(Product product) {
    // TODO Auto-generated method stub
    return 0;
  }



  @Override
  public void insertCoin(Coin coin) {
    // TODO Auto-generated method stub
    
  }



  @Override
  public List<Coin> refund() {
    // TODO Auto-generated method stub
    return null;
  }



  @Override
  public Bucket collectItemAndChange(int coinValue) {
    // TODO Auto-generated method stub
    return null;
  }



  @Override
  public void reset() {
    // TODO Auto-generated method stub
    
  }

 

}
